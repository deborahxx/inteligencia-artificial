const caixaprincipal = document.querySelector("caixa-principal");
const caixaprincipal = document. querySelector(".caixa-principal");